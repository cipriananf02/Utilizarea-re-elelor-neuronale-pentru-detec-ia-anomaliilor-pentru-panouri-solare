import torch

def evaluate_model(model, dataloader, device):
    model.eval()
    all_preds = []
    all_targets = []

    with torch.no_grad():
        for images, targets in dataloader:
            images = torch.stack(images).to(device)
            outputs = model(images)

            # Here decode outputs to boxes, labels and compare to targets
            # For demo, just accumulate dummy outputs and targets
            all_preds.append(outputs.cpu())
            all_targets.append(targets)

    # Return dummy metrics for now
    metrics = {
        "mAP": 0.0,
        "Precision": 0.0,
        "Recall": 0.0
    }
    return metrics
