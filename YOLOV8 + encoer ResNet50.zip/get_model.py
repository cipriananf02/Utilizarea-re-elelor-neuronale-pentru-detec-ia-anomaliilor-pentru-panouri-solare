import torch
import torch.nn as nn
import torchvision.models as models


class YOLOv8_ResNet50(nn.Module):
    def __init__(self, num_classes):
        super(YOLOv8_ResNet50, self).__init__()
        resnet = models.resnet50(pretrained=True)
        self.backbone = nn.Sequential(*list(resnet.children())[:-2])

        self.conv1 = nn.Conv2d(2048, 1024, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(1024)
        self.relu = nn.ReLU(inplace=True)

        # Assume 3 anchors, each predicting 5 + num_classes outputs
        self.head = nn.Conv2d(1024, 3 * (5 + num_classes), kernel_size=1)

    def forward(self, x):
        x = self.backbone(x)
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.head(x)
        return x


def get_model(num_classes):
    return YOLOv8_ResNet50(num_classes)
