import os
from PIL import Image
import torch
from torch.utils.data import Dataset
import torchvision.transforms as T

class CustomDataset(Dataset):
    def __init__(self, root_dir, split='train', transforms=None):
        self.root_dir = root_dir
        self.split = split
        self.transforms = transforms
        self.images_dir = os.path.join(root_dir, split, 'images')
        self.labels_dir = os.path.join(root_dir, split, 'labels')

        self.image_files = sorted(os.listdir(self.images_dir))
        self.label_files = sorted(os.listdir(self.labels_dir))

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = os.path.join(self.images_dir, self.image_files[idx])
        label_path = os.path.join(self.labels_dir, self.label_files[idx])

        image = Image.open(img_path).convert("RGB")
        w, h = image.size

        if self.transforms:
            image = self.transforms(image)
        else:
            image = T.ToTensor()(image)

        boxes = []
        labels = []
        with open(label_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) < 5:
                    continue
                cls, x_c, y_c, bw, bh = map(float, parts[:5])
                # Convert YOLO normalized to absolute coords xmin,ymin,xmax,ymax
                xmin = (x_c - bw / 2) * w
                ymin = (y_c - bh / 2) * h
                xmax = (x_c + bw / 2) * w
                ymax = (y_c + bh / 2) * h

                boxes.append([xmin, ymin, xmax, ymax])
                labels.append(int(cls))

        target = {
            'boxes': torch.tensor(boxes, dtype=torch.float32),
            'labels': torch.tensor(labels, dtype=torch.int64)
        }
        return image, target
