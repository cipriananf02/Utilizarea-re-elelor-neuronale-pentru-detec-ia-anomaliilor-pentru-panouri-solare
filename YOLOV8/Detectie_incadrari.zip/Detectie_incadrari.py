from PIL import Image, ImageDraw, ImageFont

def draw_boxes(img_path, results, output_file, clase):
    img = Image.open(img_path).convert("RGB")
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()
    for r in results:
        for box in r.boxes:
            cls = int(box.cls[0])
            conf = box.conf[0]
            xyxy = box.xyxy[0].tolist()  # [xmin, ymin, xmax, ymax]
            label = f"{clase[cls]} {conf:.2f}"
            draw.rectangle(xyxy, outline="red", width=2)
            draw.text((xyxy[0], xyxy[1]-10), label, fill="red", font=font)
    img.save(output_file)