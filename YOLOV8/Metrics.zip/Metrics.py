import pandas as pd

def afiseaza_metrici_csv(csv_metrics_path, n=5):
    df = pd.read_csv(csv_metrics_path)
    print(f"\nUltimele {n} epoci din {csv_metrics_path}:")
    print(df.tail(n))  # dacă vrei doar anumite coloane: df[['epoch', 'metrics/precision(B)', 'metrics/recall(B)', 'metrics/mAP50(B)']].tail(n)
