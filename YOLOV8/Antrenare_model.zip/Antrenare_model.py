import torch
from torch.utils.data import DataLoader
from Functii.dataset import YoloFormatDataset
from Functii.get_model import get_model_fasterrcnn
from Functii.evalueaza import evalueaza_model  # Importam functia de evaluare
import os


def antreneaza_model(train_images_dir, train_labels_dir,
                     valid_images_dir, valid_labels_dir,
                     num_object_classes, num_epochs, batch_size, lr, device, transforms,
                     model_save_path="best_model.pth", run_output_dir=None):  # run_output_dir pentru evaluare

    # --- Pregatirea Datelor ---
    train_dataset = YoloFormatDataset(train_images_dir, train_labels_dir, transforms=transforms)
    train_data_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True,
                                   collate_fn=YoloFormatDataset.collate_fn_ignore_errors)

    valid_dataset = YoloFormatDataset(valid_images_dir, valid_labels_dir, transforms=transforms)
    valid_data_loader = DataLoader(valid_dataset, batch_size=batch_size, shuffle=False,
                                   collate_fn=YoloFormatDataset.collate_fn_ignore_errors)

    # --- Initializarea Modelului ---
    # num_classes pentru Faster R-CNN include background-ul, deci este num_object_classes + 1
    model = get_model_fasterrcnn(num_object_classes + 1)
    model.to(device)

    # Incarca cel mai bun model anterior, daca exista, pentru a relua antrenamentul
    if os.path.exists(model_save_path):
        print(f"Încărcarea modelului anterior salvat din: {model_save_path}")
        try:
            model.load_state_dict(torch.load(model_save_path, map_location=device))
            print("Model încărcat cu succes. Reluare antrenament.")
        except Exception as e:
            print(f"Eroare la încărcarea modelului din {model_save_path}: {e}. Se va antrena de la zero.")
    else:
        print("Niciun model salvat găsit. Se va antrena de la zero.")

    optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=0.0005)

    best_map50_on_validation = 0.0  # Metrica pe care o vom folosi pentru a decide "cel mai bun" model

    print(f"Începe antrenamentul pe {num_object_classes} clase de obiecte.")

    for epoch in range(num_epochs):
        model.train()  # Seteaza modelul in modul antrenament
        print(f"\n--- Epoca {epoch + 1}/{num_epochs} ---")
        total_loss = 0
        for i, (images, targets) in enumerate(train_data_loader):
            if images is None or targets is None or len(images) == 0:
                continue

            images = list(image.to(device) for image in images)
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
            for t in targets:
                t['labels'] = t['labels'] + 1

            loss_dict = model(images, targets)
            losses = sum(loss for loss in loss_dict.values())

            optimizer.zero_grad()
            losses.backward()
            optimizer.step()

            total_loss += losses.item()

            if (i + 1) % 10 == 0:
                print(f"  Batch {i + 1} Loss: {losses.item():.4f}")

        avg_loss_train = total_loss / len(train_data_loader) if len(train_data_loader) > 0 else 0
        print(f"Epoca {epoch + 1} Pierdere Medie Antrenament: {avg_loss_train:.4f}")

        print(f"--- Rulare validare pentru Epoca {epoch + 1} ---")
        valid_metrics = evalueaza_model(
            model=model,
            data_loader=valid_data_loader,
            device=device,
            num_object_classes=num_object_classes,
            class_names=[],  # Numele claselor nu sunt necesare la validare
            visualize_images=False,  # Nu vizualizam imagini in timpul validarii
            output_dir=run_output_dir  # Directorul de salvare a imaginilor (daca vizualizezi)
        )

        current_map50_on_validation = valid_metrics['map50']
        print(f"Epoca {epoch + 1} mAP@50 Validare: {current_map50_on_validation:.4f}")

        # Salvează cel mai bun model bazat pe mAP@50 pe setul de validare
        if current_map50_on_validation > best_map50_on_validation:
            best_map50_on_validation = current_map50_on_validation
            torch.save(model.state_dict(), model_save_path)
            print(f"Model nou salvat: mAP@50 pe validare îmbunătățit la {best_map50_on_validation:.4f}")
        else:
            print(f"mAP@50 pe validare nu s-a îmbunătățit. Cel mai bun mAP@50 rămâne {best_map50_on_validation:.4f}")

    print("\nAntrenament finalizat.")
    # Returnează calea către cel mai bun model salvat, nu obiectul model în sine
    return model_save_path