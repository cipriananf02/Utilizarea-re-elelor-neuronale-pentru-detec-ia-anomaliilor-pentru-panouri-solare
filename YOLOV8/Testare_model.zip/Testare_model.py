import os
from Functii.Detectie_incadrari import draw_boxes
from ultralytics import YOLO


def testeaza_model(model_path, test_images_path, test_labels_path, output_path, clase, device):
    model = YOLO(model_path)
    nc = len(clase)
    TP = [0] * nc
    FP = [0] * nc
    FN = [0] * nc
    total_iou = 0
    total_preds = 0
    os.makedirs(output_path, exist_ok=True)
    for img_name in os.listdir(test_images_path):
        img_path = os.path.join(test_images_path, img_name)
        label_path = os.path.join(test_labels_path, os.path.splitext(img_name)[0] + '.txt')
        gt_classes = []
        if os.path.exists(label_path):
            with open(label_path, 'r') as f:
                for line in f:
                    cls = int(line.split()[0])
                    gt_classes.append(cls)
        results_test = model(img_path, device=device)
        preds = []
        for r in results_test:
            for box in r.boxes:
                preds.append(int(box.cls[0]))
                total_iou += float(box.iou[0])
                total_preds += 1

        for c in range(nc):
            tp = len([x for x in preds if x == c and c in gt_classes])
            fp = len([x for x in preds if x == c and c not in gt_classes])
            fn = len([x for x in gt_classes if x == c and c not in preds])

            TP[c] += tp
            FP[c] += fp
            FN[c] += fn

        output_file = os.path.join(output_path, img_name)
        draw_boxes(img_path, results_test, output_file, clase)

    precisions, recalls, f1s = [], [], []

    for c in range(nc):
        precision = TP[c] / (TP[c] + FP[c]) if (TP[c] + FP[c]) > 0 else 0
        recall = TP[c] / (TP[c] + FN[c]) if (TP[c] + FN[c]) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        precisions.append(precision)
        recalls.append(recall)
        f1s.append(f1)

    acuratete_test = sum(TP) / (sum(TP) + sum(FP) + sum(FN)) if (sum(TP) + sum(FP) + sum(FN)) > 0 else 0
    precision_macro_test = sum(precisions) / nc
    recall_macro_test = sum(recalls) / nc
    f1_macro_test = sum(f1s) / nc
    dice_macro_test = f1_macro_test
    iou_macro_test = total_iou / total_preds if total_preds > 0 else 0

    # mAP pe test - YOLO are evaluare dedicată, aici simulăm cu recall ca proxy, sau preferabil model.val()
    metrics_val = model.val(data=None, device=device)
    map50_test = metrics_val.results_dict['metrics/mAP50']
    map_test = metrics_val.results_dict['metrics/mAP50-95']
    loss_test = metrics_val.loss_box + metrics_val.loss_cls + metrics_val.loss_dfl

    print("\n-- Rezultate pe test --")
    print(f'Acuratețe: {acuratete_test:.4f}')
    print(f'Precizie: {precision_macro_test:.4f}')
    print(f'Recall: {recall_macro_test:.4f}')
    print(f'Dice: {dice_macro_test:.4f}')
    print(f'IoU mediu: {iou_macro_test:.4f}')
    print(f'mAP@50: {map50_test:.4f}')
    print(f'mAP@50-95: {map_test:.4f}')
    print(f'Loss total: {loss_test:.4f}')

    return {
        'acuratete_test': acuratete_test,
        'precizie_test': precision_macro_test,
        'recall_test': recall_macro_test,
        'dice_test': dice_macro_test,
        'iou_test': iou_macro_test,
        'map50_test': map50_test,
        'map_test': map_test,
        'loss_test': loss_test
    }
