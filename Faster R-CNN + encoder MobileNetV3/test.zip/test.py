import torch
from tqdm import tqdm
from Functii.metrics import calculate_map

def evaluate_model(model, dataloader, device, iou_thresholds=None):
    if iou_thresholds is None:
        iou_thresholds = [0.5, 0.75]

    model.eval()
    all_preds, all_targets = [], []

    with torch.no_grad():
        for images, targets in tqdm(dataloader, desc="Eval"):
            images = [img.to(device) for img in images]
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]

            outputs = model(images)

            for pred, target in zip(outputs, targets):
                all_preds.append(pred)
                all_targets.append(target)

    metrics_map_results = calculate_map(all_preds, all_targets, iou_thresholds)
    return metrics_map_results
