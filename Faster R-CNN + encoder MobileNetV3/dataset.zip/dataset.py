import os
from PIL import Image
import torch
from torch.utils.data import Dataset
import torchvision.transforms as t

class CustomDataset(Dataset):
    def __init__(self, split='train', transforms=None):
        self.root_dir = r'C:\Users\anfim\PycharmProjects\R2-Faster R-CNN\BD'
        self.transforms = transforms
        self.image_paths = []
        self.label_paths = []

        img_dir = os.path.join(self.root_dir, split, 'images')
        lbl_dir = os.path.join(self.root_dir, split, 'labels')

        img_files = sorted(os.listdir(img_dir))
        lbl_files = sorted(os.listdir(lbl_dir))

        for img_file, lbl_file in zip(img_files, lbl_files):
            self.image_paths.append(os.path.join(img_dir, img_file))
            self.label_paths.append(os.path.join(lbl_dir, lbl_file))

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        label_path = self.label_paths[idx]

        img = Image.open(img_path).convert("RGB")
        w, h = img.size

        if self.transforms is not None:
            img = self.transforms(img)
        else:
            img = t.ToTensor()(img)

        boxes, labels = [], []
        with open(label_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                # dacă linia are mai puțin de 5 valori, o ignorăm
                if len(parts) < 5:
                    continue
                # dacă are mai multe, luăm doar primele 5 și ignorăm restul
                cls, x_center, y_center, box_w, box_h = map(float, parts[:5])

                x_min = (x_center - box_w / 2) * w
                y_min = (y_center - box_h / 2) * h
                x_max = (x_center + box_w / 2) * w
                y_max = (y_center + box_h / 2) * h

                # sărim cutiile invalide
                if x_max <= x_min or y_max <= y_min:
                    continue

                boxes.append([x_min, y_min, x_max, y_max])
                labels.append(int(cls))

        # Dacă nu avem nicio cutie, transmitem un tensor de formă (0,4)
        if not boxes:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.int64)
        else:
            boxes = torch.as_tensor(boxes, dtype=torch.float32)
            labels = torch.as_tensor(labels, dtype=torch.int64)

        target = {
            'boxes': boxes,
            'labels': labels,
            'image_id': torch.tensor([idx], dtype=torch.int64)
        }

        return img, target