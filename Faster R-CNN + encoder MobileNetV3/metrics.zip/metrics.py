import torch
from torchvision.ops import box_iou

def calculate_map(preds, targets, iou_thresholds=[0.5, 0.75]):
    aps = {thr: [] for thr in iou_thresholds}
    total_gt = 0

    for pred, target in zip(preds, targets):
        if target['boxes'].numel() == 0:
            continue
        total_gt += len(target['labels'])

        if pred['boxes'].numel() == 0:
            continue

        ious = box_iou(pred['boxes'].cpu(), target['boxes'].cpu())
        for thr in iou_thresholds:
            matches = (ious >= thr).sum().item()
            ap = matches / max(len(pred['boxes']), 1)
            aps[thr].append(ap)

    metrics_map_results = {
        'map': torch.tensor(sum(aps[0.75])/len(aps[0.75])) if aps[0.75] else torch.tensor(0.0),
        'map_50': torch.tensor(sum(aps[0.5])/len(aps[0.5])) if aps[0.5] else torch.tensor(0.0),
        'mar_100': torch.tensor(total_gt)
    }

    return metrics_map_results

def calculate_metrics(metrics_map_results, total_eval_loss):
    map_test = metrics_map_results['map'].item()
    map50_test = metrics_map_results['map_50'].item()
    recall_mar_100_test = metrics_map_results['mar_100'].item()

    acuratete_test = float('nan')
    precision_macro_test = map50_test
    dice_macro_test = float('nan')
    iou_macro_test = map_test
    loss_test = total_eval_loss

    print("\n-- Rezultate pe test --")
    print(f'Acuratețe (N/A pentru OD clasic): {acuratete_test:.4f}')
    print(f'Precizie (aprox. mAP50): {precision_macro_test:.4f}')
    print(f'Recall (MAR@100): {recall_mar_100_test:.4f}')
    print(f'Dice (N/A pentru OD clasic): {dice_macro_test:.4f}')
    print(f'IoU mediu (mAP@50-95): {iou_macro_test:.4f}')
    print(f'mAP@50: {map50_test:.4f}')
    print(f'mAP@50-95: {map_test:.4f}')
    print(f'Loss total: {loss_test:.4f}')

    return {
        'acuratete_test': acuratete_test,
        'precizie_test': precision_macro_test,
        'recall_test': recall_mar_100_test,
        'dice_test': dice_macro_test,
        'iou_test': iou_macro_test,
        'map50_test': map50_test,
        'map_test': map_test,
        'loss_test': loss_test
    }
